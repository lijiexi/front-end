
$(document).ready(function(){
	
	$(".form-first-name").val("First name...");
	$(".form-last-name").val("Last name...");
	$(".form-email").val("Email...");
	$(".form-about-yourself").val("About yourself...");
	
});